package com.example.hyun.drawnav;

import android.os.Bundle;

import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.nhn.android.maps.NMapActivity;
import com.nhn.android.maps.NMapController;
import com.nhn.android.maps.NMapView;
import com.nhn.android.maps.maplib.NGeoPoint;
import com.nhn.android.maps.nmapmodel.NMapError;

/**
 * Created by Hyun on 2017-10-27.
 */

public class map extends AppCompatActivity {



    //다이알로그
    AlertDialog select;
    View selmap;
    TextView xbtn;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main2);
        //다이알로그 정의
        selmap = View.inflate(getApplicationContext(),R.layout.activity_map,null);
        select = new AlertDialog.Builder(map.this).setView(selmap).create();

        select.show();

        xbtn = (TextView) selmap.findViewById(R.id.x);
        xbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                select.dismiss();
                finish();
            }
        });



    }

}

